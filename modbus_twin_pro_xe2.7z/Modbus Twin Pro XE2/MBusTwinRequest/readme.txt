Modbus Twin Request Pro
GNU License v3 (GPL v3)

With this software you can send and receive modbus serial or ip request to compatible devices.

Features
�	Modbus serial
�	Modbus Tcp/Ip
�	Scanner
�	Transfer PLC <-> PC
�	Request model
�	Request load/Save
�	CSV export 


Written by Guillaume Estrada (c) 2012-2019

 
-------------------------------------------------------------------------------


Modbus Twin Request Pro

Envoyez et recevez des requ�tes Modbus sur port s�rie et/ou Tcp/Ip.

Caract�ristiques
�	Modbus s�rie
�	Modbus Tcp/Ip
�	Scanner
�	Transfert automate <-> PC
�	Mod�le de requ�te
�	Chargement/sauvegarde requ�te
�	Export en csv


Ecrit par Guillaume Estrada (c) 2012-2019


