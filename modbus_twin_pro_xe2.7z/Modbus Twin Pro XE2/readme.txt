Modbus Twin Request 
by Guillaume Estrada
Written in Delphi
GNU License v3 (GPL v3)

With this software you can send and receive modbus serial or ip request to compatible devices.

Features
· Modbus serial
· Modbus Tcp/Ip
· Scanner
· Transfer PLC <-> PC
· Request model
· Request load/Save
· CSV export
· Value tracker


Version: 1.3.0.2
